/**
 * Created by Michael K. on 3/8/2016.
 */
public class VisualSettings extends Coggie {
}
