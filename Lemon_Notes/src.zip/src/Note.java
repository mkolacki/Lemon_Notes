/**
 * Created by Michael K. on 3/8/2016.
 */
public class Note {
    String note;
    String subject;

    public Note(String note_to_be_made, String note_subject){
        note = note_to_be_made;
        subject = note_subject;
    }
}
