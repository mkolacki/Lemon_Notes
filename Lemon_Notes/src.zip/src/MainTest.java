import static org.junit.Assert.*;

/**
 * Created by alex on 3/6/2016.
 */
public class MainTest
{

    @org.junit.Test
    public void testMain() throws Exception
    {

    }

    @org.junit.Test
    public void testStart() throws Exception
    {

    }
}